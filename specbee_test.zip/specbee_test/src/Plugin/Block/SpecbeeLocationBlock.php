<?php

namespace Drupal\specbee_test\Plugin\Block;


use Drupal\Core\Block\BlockBase;


/**
 * Provides a 'Specbee location ' block.
 *
 * @Block(
 *   id = "specbee_location_block",
 *   admin_label = @Translation("Specbee location block")
 * )
 */
class SpecbeeLocationBlock extends BlockBase  {

  
  /**
   * {@inheritdoc}
   */
  public function build() {
    $service = \Drupal::service('specbee_test.get_location');
    return [
        '#theme' => 'specbee_location',
        '#cache' => [
          'max-age' => 0,
        ],
        '#location' => $service->getLocationData(),
    ];
  }

}
