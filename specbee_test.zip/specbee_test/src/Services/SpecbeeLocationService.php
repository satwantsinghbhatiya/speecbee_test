<?php

namespace Drupal\specbee_test\Services;
use Drupal\Core\Datetime\DrupalDateTime;

/**
 * Class SpecbeeLocationService.
 */
class SpecbeeLocationService {

  public function getLocationData() {
    $config = \Drupal::config('specbee_test.settings');
    $now = DrupalDateTime::createFromTimestamp(time());
    $timezone = "";
    $timezone = $config->get('timezone');
    $now->setTimezone(new \DateTimeZone($timezone));
    $location = $config->get('country') . ", " . $config->get('city') . " " . $now->format('dS F Y H:i A');
    return $location;
  }
}